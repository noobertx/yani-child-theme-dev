<?php get_header();?>
<div id="page">
	<main>
		<?php get_template_part('loop','single'); ?>
	</main>
</div>
<?php get_footer();?>