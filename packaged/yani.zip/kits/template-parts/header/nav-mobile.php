<div class="nav-mobile">
    <div class="main-nav navbar slideout-menu slideout-menu-left" id="nav-mobile">
        <?php get_template_part('template-parts/header/partials/mobile-nav'); ?>
    </div><!-- main-nav -->
</div><!-- nav-mobile -->