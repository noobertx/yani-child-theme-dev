		Footer Here
		<footer class="bg-dark">
				
		</footer>

		<?php wp_footer();?>
	</body>
</html>