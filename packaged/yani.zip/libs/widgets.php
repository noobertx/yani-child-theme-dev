<?php
	// add_action("widgets_init","yani_sidebars");
?>