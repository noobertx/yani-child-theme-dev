<?php
function yani_register_menus(){
	register_nav_menus(array(
		'main-menu' => esc_html__('Main Menu','yani')
	));
}

add_action('init','yani_register_menus');
function yani_dropdown_icon($title,$item,$args,$depth){

	if($args->theme_location == 'main-menu'){
		if(in_array("menu-item-has-children",$item->classes)){
			if($depth == 0){
				// $title .= "<i class='fas fa-angle-down' aria-hidden='true'></i>";
			}else{
				// $title .= "<i class='fa fa-angle-down' aria-hidden='true'></i>";
			}
		}
	}
	return $title;
}

add_filter('nav_menu_item_title','yani_dropdown_icon',10,4);
?>