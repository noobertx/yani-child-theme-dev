<?php

function yani_add_meta_box(){
	add_meta_box(
		'yani_post_metabox',
		'Page Settings',
		'yani_post_metabox_render',
		'page',
		'normal',
		'default'
	);
}
add_action('add_meta_boxes','yani_add_meta_box');

function yani_post_metabox_render($post){ 
	$hide_title = get_post_meta($post->ID,'_yani_hide_title',false)[0];
	wp_nonce_field('yani_update_post_metabox','yani_update_post_nonce');
	?>

	<p>
		<label for="yani_hide_title"><?php esc_html_e("Hide Page Title","yani");?>Hide Title</label>
		<select name="hide_title_field" id="yani_hide_title" value="<?php echo $hide_title;?>">
			<option value="" <?php echo ($hide_title=="") ? "selected" : "" ;?>>No</option>
			<option value="yes" <?php echo ($hide_title=="yes") ? "selected" : "" ;?>>Yes</option>
		</select>
	</p>
<?php } 

add_action('save_post','yani_save_post_metabox',10,2);
function yani_save_post_metabox($post_id,$post){

	$edit_cap = get_post_type_object($post->post_type)->cap->edit_post;
	if(!current_user_can($edit_cap ,$post_id)){
		return;
	}

	if(!isset($_POST['yani_update_post_nonce']) 
		|| !wp_verify_nonce($_POST['yani_update_post_nonce'],'yani_update_post_metabox')){
		return;
	}

	if(array_key_exists('hide_title_field',$_POST)){		
		$display_title = sanitize_text_field($_POST['hide_title_field']);
		update_post_meta($post->ID,"_yani_hide_title",$display_title);
	}
}
?>