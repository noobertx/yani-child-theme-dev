<?php 
function yani_sidebar_widgets(){
	register_sidebar(array(
		'id' => 'primary-sidebar',
		'name' => esc_html(__('Primary Sidebar','yani')),
		'description' => esc_html(__('Sidebar Appears','yani')),
		'before_widget' => '<section id="%1$s" class="">',
		'after_widget' => '</section>',
		'before_title' => '<h5>',
		'after_title' => '</h5>',
	));
}

add_action('widgets_init','yani_sidebar_widgets');
function yani_footer_widgets(){
	$columns = [3,3,3,3];

	foreach($columns as $i => $column){
		register_sidebar(array(
			'id' => 'footer-sidebar-'.$i,
			'name' => esc_html(__('Footer Sidebar ('.($i+1).')' ,'yani')),
			'description' => esc_html(__('Footer Widgets','yani')),
			'before_widget' => '<section id="%1$s" class="">',
			'after_widget' => '</section>',
			'before_title' => '<h5>',
			'after_title' => '</h5>',
		));
	}
}
add_action('widgets_init','yani_footer_widgets');
?>