<ul class="item-price-wrap hide-on-list">
	<?php echo _yani_property_listing()->get_price_v1(); ?>
</ul>