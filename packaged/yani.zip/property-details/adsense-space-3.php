<div class="adv-wrapper">
	<?php echo yani_option('adsense_space_3');?>
</div>