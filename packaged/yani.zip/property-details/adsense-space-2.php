<div class="adv-wrapper">
	<?php echo yani_option('adsense_space_2');?>
</div>