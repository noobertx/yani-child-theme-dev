<?php get_header();?>


<div id="page">
	
<main >


<?php the_content();?>	

</main>

</div>

<?php get_footer();?>