<div id="side-slide-simple" class="side-slide-simple" data-width="250">
	<div class="close-wrapper">
		<a href="#" class="close">
			<i class="yani-icon icon-close"></i>
		</a>
	</div>
	<div class="menu-class">
		<nav class="main-nav on-hover-menu navbar-expand-lg flex-grow-1">
            <?php get_template_part('template-parts/header/partials/nav'); ?>
        </nav><!-- main-nav -->
	</div>
</div>