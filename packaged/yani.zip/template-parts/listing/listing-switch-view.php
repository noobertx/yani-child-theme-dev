<div class="listing-switch-view">
	<ul class="list-inline">
		<li class="list-inline-item">
			<a class="switch-btn btn-list">
				<i class="yani-icon icon-layout-bullets"></i>List
			</a>
		</li>
		<li class="list-inline-item">
			<a class="switch-btn btn-grid">
				<i class="yani-icon icon-layout-module-1"></i>Grid
			</a>
		</li>
	</ul>
</div><!-- listing-switch-view -->