 <?php if( yani_option('copy_rights') != '' ) { ?>
<div class="footer-copyright">
	&copy; <?php echo yani_option('copy_rights'); ?>
</div><!-- footer-copyright -->
<?php } ?>