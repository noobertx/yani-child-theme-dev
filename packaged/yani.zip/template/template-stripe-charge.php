<?php
/**
 * Template Name: Stripe Charge Page
 * Created by PhpStorm.
 * User: waqasriaz
 * Date: 27/06/16
 * Time: 5:18 AM
 */

if(!isset($_POST['stripeEmail'])){
    die("Cannot acces page Directly");
}

require_once( get_template_directory() . '/framework/stripe-php/init.php' );
$allowed_html = array();

$current_user = wp_get_current_user();
$userID       =   $current_user->ID;
$user_email   =   $current_user->user_email;
$admin_email  =  get_bloginfo('admin_email');
$username     =   $current_user->user_login;
$submission_currency = _yani_theme()->get_option('currency_paid_submission');
$thankyou_page_link = _yani_template()->get_template_link('template/template-thankyou.php');
$paymentMethod = 'Stripe';
$time = time();
$date = date('Y-m-d H:i:s',$time);

$stripe_secret_key = _yani_theme()->get_option('stripe_secret_key');
$stripe_publishable_key = _yani_theme()->get_option('stripe_publishable_key');
$stripe = array(
    "secret_key"      => $stripe_secret_key,
    "publishable_key" => $stripe_publishable_key
);
\Stripe\Stripe::setApiKey($stripe['secret_key']);

/*--------------------------------------------------------------
* Webhook Start
---------------------------------------------------------------*/

$input      = @file_get_contents( "php://input" );
$event_json = json_decode( $input );
 
if( $event_json != '') {

    // Get stripe customer id.
    $customer_stripe_id = $event_json->data->object->customer;


    if( $event_json->type == 'invoice.payment_failed'){   
        $args=array('meta_key'    => 'yani_stripe_user_profile', 
                    'meta_value'  => $customer_stripe_id
                );
        $customers=get_users( $args ); 
        foreach ( $customers as $user ) {
            update_user_meta( $user->ID, 'yani_stripe_user_profile', '' );
        }       
    }
    
    
    // Charge Recurring
    if( $event_json->type =='payment_intent.succeeded') {
        $args = array('meta_key'      => 'yani_stripe_user_profile', 
                    'meta_value'    => $customer_stripe_id
        );
        
        $update_user_id =   0;
        $customers=get_users( $args ); 
        foreach ( $customers as $user ) {
            $update_user_id = $user->ID;
        } 
        $pack_id = intval (get_user_meta($update_user_id, 'package_id',true));

        if($update_user_id!=0 && $pack_id!=0){
            _yani_membership()->save_user_record($update_user_id);
            if( _yani_membership()->check_user_package_status($update_user_id, $pack_id) ){
                _yani_membership()->downgrade_package( $update_user_id, $pack_id );
                _yani_membership()->update_membership_package($update_user_id, $pack_id);
            }else{
                _yani_membership()->update_membership_package($update_user_id, $pack_id);
            }    
        
        }else{
           // echo 'no user exist';           
        } 
        
        $args = array(
            'recurring_package_name' => get_the_title($pack_id),
            'merchant'               => 'Stripe'
        );
        _yani_email()->send_email_type( $user->user_email, 'recurring_payment', $args );
           
    }
    
    http_response_code(200); 
    exit();
}

/*---------------------------
* End webhook
---------------------------------------------------------------------*/


if( is_email($_POST['stripeEmail']) ) {  // done
    $stripeEmail=  wp_kses ( esc_html($_POST['stripeEmail']) ,$allowed_html );
} else {
    wp_die('None Mail');
}

if( isset($_POST['userID']) && !is_numeric( $_POST['userID'] ) ) { //done
    die();
}

if( isset($_POST['propID']) && !is_numeric( $_POST['propID'] ) ) { //done
    die();
}

if( isset($_POST['submission_pay']) && !is_numeric( $_POST['submission_pay'] ) ) { //done
    die();
}

if( isset($_POST['pack_id']) && !is_numeric( $_POST['pack_id'] ) ){
    die();
}

if( isset($_POST['pay_ammout']) && !is_numeric( $_POST['pay_ammout'] ) ) { //done
    die();
}

if( isset($_POST['featured_pay']) && !is_numeric( $_POST['featured_pay'] ) ){
    die();
}

if( isset($_POST['is_upgrade']) && !is_numeric( $_POST['is_upgrade'] ) ){
    die();
}

if( isset($_POST['yani_stripe_recurring']) && !is_numeric( $_POST['yani_stripe_recurring'] ) ){
    die();
}

if ( isset ($_POST['submission_pay'])  && $_POST['submission_pay'] == 1  ) {
    try {
        $token  = wp_kses ( $_POST['stripeToken'] ,$allowed_html);

        $customer = \Stripe\Customer::create(array(
            "email" => $stripeEmail,
            "source" => $token // obtained with Stripe.js
        ));

        $userId      = intval( $_POST['userID'] );
        $listing_id  = intval( $_POST['propID'] );
        $pay_ammout  = intval( $_POST['pay_ammout'] );
        $is_featured = 0;
        $is_upgrade  = 0;

        if ( isset($_POST['featured_pay']) && $_POST['featured_pay']==1 ){
            $is_featured    =   intval($_POST['featured_pay']);
        }

        if ( isset($_POST['is_upgrade']) && $_POST['is_upgrade']==1 ){
            $is_upgrade = intval($_POST['is_upgrade']);
        }

        $price_per_submission = floatval(_yani_theme()->get_option('price_listing_submission'));
        $price_featured_submission = floatval(_yani_theme()->get_option('price_featured_listing_submission'));
        $price_per_submission      = floatval( $price_per_submission * 100 );
        $price_featured_submission = floatval( $price_featured_submission * 100);
        

        $charge = \Stripe\Charge::create(array(
            "amount" => $pay_ammout,
            'customer' => $customer->id,
            "currency" => $submission_currency,
            //"source" => "tok_18Qks9IwlqUqVdUMkzqkPsbV", // obtained with Stripe.js
            //"description" => ""
        ));

        if( $is_upgrade == 1 ) {
            update_post_meta( $listing_id, 'yani_featured', 1 );
            $invoice_id = _yani_invoice()->generate_invoice( 'Upgrade to Featured', 'one_time', $listing_id, $date, $userID, 0, 1, '', $paymentMethod );
            update_post_meta( $invoice_id, 'invoice_payment_status', 1 );

            $args = array(
                'listing_title'  =>  get_the_title($listing_id),
                'listing_id'     =>  $listing_id,
                'invoice_no'     =>  $invoice_id,
                'listing_url'    =>  get_permalink($listing_id),
            );

            /*
             * Send email
             * */
            _yani_email()->send_email_type( $user_email, 'featured_submission_listing', $args);
            _yani_email()->send_email_type( $admin_email, 'admin_featured_submission_listing', $args);

        } else {
            update_post_meta( $listing_id, 'yani_payment_status', 'paid' );

            $paid_submission_status    = _yani_theme()->get_option('enable_paid_submission');
            $listings_admin_approved = _yani_theme()->get_option('listings_admin_approved');

            

            if( $listings_admin_approved != 'yes'  && $paid_submission_status == 'per_listing' ){
                $post = array(
                    'ID'            => $listing_id,
                    'post_status'   => 'publish'
                );

                if( isset($_POST['relist_mode']) &&  $_POST['relist_mode'] != "" ) {
                    $post['post_date'] = current_time( 'mysql' );
                }

                $post_id =  wp_update_post($post );
            } else {
                $post = array(
                    'ID'            => $listing_id,
                    'post_status'   => 'pending'
                );

                if( isset($_POST['relist_mode']) &&  $_POST['relist_mode'] != "" ) {
                    $post['post_date'] = current_time( 'mysql' );
                }

                $post_id =  wp_update_post($post );
            }


            if( $is_featured == 1 ) {
                update_post_meta( $listing_id, 'yani_featured', 1 );
                $invoice_id = _yani_invoice()->generate_invoice( 'Publish Listing with Featured', 'one_time', $listing_id, $date, $userID, 1, 0, '', $paymentMethod );
            } else {
                $invoice_id = _yani_invoice()->generate_invoice( 'Listing', 'one_time', $listing_id, $date, $userID, 0, 0, '', $paymentMethod );
            }
            update_post_meta( $invoice_id, 'invoice_payment_status', 1 );

            $args = array(
                'listing_title'  =>  get_the_title($listing_id),
                'listing_id'     =>  $listing_id,
                'invoice_no'     =>  $invoice_id,
                'listing_url'    =>  get_permalink($listing_id),
            );

            /*
             * Send email
             * */
            _yani_email()->send_email_type( $user_email, 'paid_submission_listing', $args);
            _yani_email()->send_email_type( $admin_email, 'admin_paid_submission_listing', $args);
        }

        wp_redirect( $thankyou_page_link ); exit;

    }
    catch (Exception $e) {
        $error = '<div class="alert alert-danger">
                <strong>Error!</strong> '.$e->getMessage().'
                </div>';
        print $error;
    }

} else if ( isset ($_POST['yani_stripe_recurring'] ) && $_POST['yani_stripe_recurring'] == 1 ) {
    /*----------------------------------------------------------------------------------------
    * Payment for Stripe package recuring
    *-----------------------------------------------------------------------------------------*/
    try {
        $token          =   wp_kses ( esc_html($_POST['stripeToken']) ,$allowed_html);
        $pack_id        =   intval($_POST['pack_id']);
        $stripe_plan    =   esc_html(get_post_meta($pack_id, 'yani_package_stripe_id', true));

        $customer_args = apply_filters(
            'yani_stripe_customer_args',
            array(
                'email'  => $stripeEmail,
                'source' => $token,
            )
        );

        $customer = \Stripe\Customer::create( $customer_args );

        $stripe_customer_id = $customer->id;
 
        $subscription_args = apply_filters(
            'yani_stripe_subscription_args',
            array(
                'customer' => $stripe_customer_id,
                'plan'     => $stripe_plan,
            )
        );

        $subscription = \Stripe\Subscription::create( $subscription_args );


        _yani_membership()->save_user_record($userID);
        if( _yani_membership()->check_user_package_status($current_user->ID, $pack_id) ){
            _yani_membership()->downgrade_package( $current_user->ID, $pack_id );
            _yani_membership()->update_membership_package($userID, $pack_id);
        }else{
            _yani_membership()->update_membership_package($userID, $pack_id);
        }

        $invoiceID = _yani_invoice()->generate_invoice( 'package', 'recurring', $pack_id, $date, $userID, 0, 0, '', $paymentMethod, 1 );
        update_post_meta( $invoiceID, 'invoice_payment_status', 1 );

        $current_stripe_customer_id =  get_user_meta( $current_user->ID, 'yani_stripe_user_profile', true );
        $is_stripe_recurring        =   get_user_meta( $current_user->ID, 'yani_has_stripe_recurring',true );
        if ($current_stripe_customer_id !=='' && $is_stripe_recurring == 1 ) {
            if( $current_stripe_customer_id !== $stripe_customer_id ){
                _yani_payment()->stripe_cancel_subscription();
            }
        }


        update_user_meta( $current_user->ID, 'yani_stripe_user_profile', $stripe_customer_id );
        update_user_meta( $current_user->ID, 'yani_stripe_subscription_id', $subscription->id );
        update_user_meta( $current_user->ID, 'yani_stripe_subscription_due', $subscription->current_period_end );
        update_user_meta( $current_user->ID, 'yani_has_stripe_recurring', 1 );

        $args = array();
        _yani_email()->send_email_type( $user_email,'purchase_activated_pack', $args );

        wp_redirect( $thankyou_page_link ); exit;

    }
    catch (Exception $e) {
        $error = '<div class="alert alert-danger">
                  <strong>Error!</strong> '.$e->getMessage().'
                  </div>';
        print $error;
    }
} else {

    /*----------------------------------------------------------------------------------------
    * Payment for Stripe package
    *-----------------------------------------------------------------------------------------*/
    try {

        $token  = wp_kses (esc_html($_POST['stripeToken']),$allowed_html);
        $customer = \Stripe\Customer::create(array(
            "email" => $stripeEmail,
            "source" => $token // obtained with Stripe.js
        ));

        $dash_profile_link = yani_get_dashboard_profile_link();
        $userId     =   intval($_POST['userID']);
        $pay_ammout =   intval($_POST['pay_ammout']);
        $pack_id    =   intval($_POST['pack_id']);

        $charge = \Stripe\Charge::create(array(
            "amount" => $pay_ammout,
            'customer' => $customer->id,
            "currency" => $submission_currency,
            //"source" => "tok_18Qks9IwlqUqVdUMkzqkPsbV", // obtained with Stripe.js
            //"description" => ""
        ));

        _yani_membership()->save_user_record($userID);
        if( _yani_membership()->check_user_package_status($current_user->ID,$pack_id) ){
            _yani_membership()->downgrade_package( $current_user->ID, $pack_id );
            _yani_membership()->update_membership_package($userID, $pack_id);
        }else{
            _yani_membership()->update_membership_package($userID, $pack_id);
        }

        $invoiceID = _yani_invoice()->generate_invoice( 'package', 'one_time', $pack_id, $date, $userID, 0, 0, '', $paymentMethod, 1 );
        update_post_meta( $invoiceID, 'invoice_payment_status', 1 );


        update_user_meta( $current_user->ID, 'yani_has_stripe_recurring', 0 );

        $args = array();
        _yani_email()->send_email_type( $user_email,'purchase_activated_pack', $args );

        wp_redirect( $thankyou_page_link ); exit;

    }
    catch (Exception $e) {
        $error = '<div class="alert alert-danger">
                  <strong>Error!</strong> '.$e->getMessage().'
                  </div>';
        print $error;
    }
}
?>